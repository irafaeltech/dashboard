import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { teamsRoutes } from './routes/teams.js';
import { zoomRoutes } from './routes/zoom.js';
import { googleRoutes } from './routes/google.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/teams', teamsRoutes);
app.use('/api/zoom', zoomRoutes);
app.use('/api/google', googleRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'An unexpected error occurred'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;