import axios from 'axios';

export class ZoomService {
  constructor(accessToken) {
    this.client = axios.create({
      baseURL: 'https://api.zoom.us/v2',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
  }

  async getUnreadMessages() {
    try {
      const response = await this.client.get('/chat/users/me/messages', {
        params: {
          status: 'unread'
        }
      });

      return response.data.total_records || 0;
    } catch (error) {
      console.error('Error fetching Zoom messages:', error);
      throw error;
    }
  }
}