import { Client } from '@microsoft/microsoft-graph-client';
import { TokenCredentialAuthenticationProvider } from '@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials';

export class TeamsService {
  constructor(accessToken) {
    const authProvider = new TokenCredentialAuthenticationProvider({
      getToken: async () => accessToken
    });

    this.client = Client.initWithMiddleware({
      authProvider
    });
  }

  async getUnreadMessages() {
    try {
      const response = await this.client
        .api('/me/messages')
        .filter('isRead eq false')
        .select('id')
        .get();

      return response.value.length;
    } catch (error) {
      console.error('Error fetching Teams messages:', error);
      throw error;
    }
  }
}