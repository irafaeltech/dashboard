import { google } from 'googleapis';

export class GoogleService {
  constructor(accessToken) {
    this.oauth2Client = new google.auth.OAuth2();
    this.oauth2Client.setCredentials({
      access_token: accessToken
    });

    this.gmail = google.gmail({
      version: 'v1',
      auth: this.oauth2Client
    });
  }

  async getUnreadMessages() {
    try {
      const response = await this.gmail.users.messages.list({
        userId: 'me',
        q: 'is:unread'
      });

      return response.data.messages?.length || 0;
    } catch (error) {
      console.error('Error fetching Google messages:', error);
      throw error;
    }
  }
}