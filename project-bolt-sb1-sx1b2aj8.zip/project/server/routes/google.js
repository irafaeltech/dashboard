import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { GoogleService } from '../services/google.js';
import { google } from 'googleapis';

const router = express.Router();

router.get('/unread', verifyToken, async (req, res) => {
  try {
    const googleService = new GoogleService(req.user.googleToken);
    const count = await googleService.getUnreadMessages();
    res.json({ count });
  } catch (error) {
    console.error('Google API error:', error);
    res.status(500).json({ error: 'Failed to fetch Google messages' });
  }
});

router.post('/authorize', async (req, res) => {
  try {
    const { code } = req.body;
    
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URI
    );

    // In a real implementation, exchange the code for tokens
    // const { tokens } = await oauth2Client.getToken(code);

    res.json({
      success: true,
      accessToken: 'mock_google_token',
      expiresIn: 3600
    });
  } catch (error) {
    console.error('Google authorization error:', error);
    res.status(500).json({ error: 'Failed to authorize with Google' });
  }
});

export const googleRoutes = router;