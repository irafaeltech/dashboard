import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { ZoomService } from '../services/zoom.js';

const router = express.Router();

router.get('/unread', verifyToken, async (req, res) => {
  try {
    const zoomService = new ZoomService(req.user.zoomToken);
    const count = await zoomService.getUnreadMessages();
    res.json({ count });
  } catch (error) {
    console.error('Zoom API error:', error);
    res.status(500).json({ error: 'Failed to fetch Zoom messages' });
  }
});

router.post('/authorize', async (req, res) => {
  try {
    const { code } = req.body;
    
    const params = new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: process.env.ZOOM_REDIRECT_URI
    });

    const auth = Buffer.from(`${process.env.ZOOM_CLIENT_ID}:${process.env.ZOOM_CLIENT_SECRET}`).toString('base64');
    
    // In a real implementation, make this request to Zoom
    // const response = await axios.post('https://zoom.us/oauth/token', params, {
    //   headers: {
    //     Authorization: `Basic ${auth}`
    //   }
    // });

    res.json({
      success: true,
      accessToken: 'mock_zoom_token',
      expiresIn: 3600
    });
  } catch (error) {
    console.error('Zoom authorization error:', error);
    res.status(500).json({ error: 'Failed to authorize with Zoom' });
  }
});

export const zoomRoutes = router;