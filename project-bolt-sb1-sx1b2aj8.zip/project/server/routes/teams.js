import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { TeamsService } from '../services/teams.js';

const router = express.Router();

router.get('/unread', verifyToken, async (req, res) => {
  try {
    const teamsService = new TeamsService(req.user.teamsToken);
    const count = await teamsService.getUnreadMessages();
    res.json({ count });
  } catch (error) {
    console.error('Teams API error:', error);
    res.status(500).json({ error: 'Failed to fetch Teams messages' });
  }
});

router.post('/authorize', async (req, res) => {
  try {
    const { code } = req.body;
    
    // Exchange code for access token using MSAL
    const msalConfig = {
      auth: {
        clientId: process.env.MICROSOFT_CLIENT_ID,
        authority: 'https://login.microsoftonline.com/common',
        clientSecret: process.env.MICROSOFT_CLIENT_SECRET
      }
    };

    // In a real implementation, use MSAL to get tokens
    // const result = await msalClient.acquireTokenByCode(code);
    
    res.json({
      success: true,
      accessToken: 'mock_teams_token',
      expiresIn: 3600
    });
  } catch (error) {
    console.error('Teams authorization error:', error);
    res.status(500).json({ error: 'Failed to authorize with Teams' });
  }
});

export const teamsRoutes = router;