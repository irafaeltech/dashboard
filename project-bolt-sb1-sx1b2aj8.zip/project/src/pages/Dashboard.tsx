import React, { useEffect } from 'react';
import MessageCard from '../components/MessageCard';
import { useMessage } from '../context/MessageContext';
import { BadgeCheck as MessageBadgeCheck, RefreshCw } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { 
    messages, 
    loading, 
    error, 
    lastUpdated, 
    refreshMessages 
  } = useMessage();

  useEffect(() => {
    // Initial load of messages
    refreshMessages();
    
    // Set up auto-refresh every 60 seconds
    const intervalId = setInterval(() => {
      refreshMessages();
    }, 60000);
    
    return () => clearInterval(intervalId);
  }, [refreshMessages]);

  const formatLastUpdated = (timestamp: Date | null) => {
    if (!timestamp) return 'Never';
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(timestamp);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Message Notification Hub</h1>
        <p className="text-gray-600">Your unified dashboard for unread messages across platforms</p>
      </div>

      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <MessageBadgeCheck className="w-5 h-5 text-indigo-600 mr-2" />
          <span className="text-sm text-gray-600">
            Last updated: {formatLastUpdated(lastUpdated)}
          </span>
        </div>
        <button 
          onClick={refreshMessages}
          disabled={loading}
          className="flex items-center px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 
                     transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh Now
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
          <p className="font-medium">Error refreshing messages</p>
          <p className="text-sm">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MessageCard 
          platform="teams" 
          count={messages.teams}
          loading={loading}
        />
        <MessageCard 
          platform="zoom" 
          count={messages.zoom}
          loading={loading}
        />
        <MessageCard 
          platform="google" 
          count={messages.google}
          loading={loading}
        />
      </div>
    </div>
  );
};

export default Dashboard;