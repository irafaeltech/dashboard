import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { MessageCircleMore } from 'lucide-react';
import LoginButton from '../components/LoginButton';

const Login: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  useEffect(() => {
    // If already authenticated, redirect to dashboard
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  // Handle OAuth callback
  useEffect(() => {
    const query = new URLSearchParams(location.search);
    const code = query.get('code');
    const state = query.get('state');
    const error = query.get('error');
    
    if (code && state) {
      // TODO: Implement OAuth callback handling
      console.log('OAuth callback received', { code, state });
    }
    
    if (error) {
      console.error('OAuth error', error);
    }
  }, [location]);
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center px-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <MessageCircleMore size={32} className="text-indigo-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Message Notification Hub</h1>
          <p className="text-gray-600 mt-2">Connect your accounts to see all unread messages in one place</p>
        </div>
        
        <div className="space-y-4">
          <LoginButton platform="teams" />
          <LoginButton platform="zoom" />
          <LoginButton platform="google" />
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200 text-center text-sm text-gray-500">
          <p>By connecting your accounts, you grant permission to read notification data from these services.</p>
        </div>
      </div>
    </div>
  );
};

export default Login;