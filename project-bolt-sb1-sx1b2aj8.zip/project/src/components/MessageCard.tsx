import React from 'react';
import { 
  MessageSquare, 
  Video, 
  Mail,
  Loader2
} from 'lucide-react';

type Platform = 'teams' | 'zoom' | 'google';

interface MessageCardProps {
  platform: Platform;
  count: number;
  loading: boolean;
}

const platformConfig = {
  teams: {
    name: 'Microsoft Teams',
    icon: MessageSquare,
    color: 'bg-[#6264A7]',
    textColor: 'text-[#6264A7]',
    borderColor: 'border-[#6264A7]',
    bgColor: 'bg-purple-50'
  },
  zoom: {
    name: 'Zoom',
    icon: Video,
    color: 'bg-[#2D8CFF]',
    textColor: 'text-[#2D8CFF]',
    borderColor: 'border-[#2D8CFF]',
    bgColor: 'bg-blue-50'
  },
  google: {
    name: 'Google Meet',
    icon: Mail,
    color: 'bg-[#EA4335]',
    textColor: 'text-[#EA4335]',
    borderColor: 'border-[#EA4335]',
    bgColor: 'bg-red-50'
  }
};

const MessageCard: React.FC<MessageCardProps> = ({ platform, count, loading }) => {
  const config = platformConfig[platform];
  
  return (
    <div className={`rounded-lg shadow-sm border ${config.borderColor} overflow-hidden transition-all duration-300 hover:shadow-md`}>
      <div className={`${config.color} p-4 text-white`}>
        <div className="flex items-center">
          <config.icon className="w-5 h-5 mr-2" />
          <h3 className="font-medium">{config.name}</h3>
        </div>
      </div>
      
      <div className={`${config.bgColor} p-6 flex flex-col items-center justify-center min-h-[140px]`}>
        {loading ? (
          <Loader2 className={`w-8 h-8 ${config.textColor} animate-spin`} />
        ) : (
          <>
            <div className={`text-4xl font-bold ${config.textColor} mb-2`}>
              {count}
            </div>
            <p className="text-gray-600 text-sm">
              {count === 1 ? 'Unread Message' : 'Unread Messages'}
            </p>
          </>
        )}
      </div>
    </div>
  );
};

export default MessageCard;