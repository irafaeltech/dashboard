import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  MessageSquare, 
  Video, 
  Mail
} from 'lucide-react';

type Platform = 'teams' | 'zoom' | 'google';

interface LoginButtonProps {
  platform: Platform;
}

const platformConfig = {
  teams: {
    name: 'Microsoft Teams',
    icon: MessageSquare,
    color: 'bg-[#6264A7]',
    hoverColor: 'hover:bg-[#4B4C7D]',
    textColor: 'text-[#6264A7]'
  },
  zoom: {
    name: 'Zoom',
    icon: Video,
    color: 'bg-[#2D8CFF]',
    hoverColor: 'hover:bg-[#2473CC]',
    textColor: 'text-[#2D8CFF]'
  },
  google: {
    name: 'Google Meet',
    icon: Mail,
    color: 'bg-[#EA4335]',
    hoverColor: 'hover:bg-[#D03A2F]',
    textColor: 'text-[#EA4335]'
  }
};

const LoginButton: React.FC<LoginButtonProps> = ({ platform }) => {
  const { login, connectedServices } = useAuth();
  const config = platformConfig[platform];
  const isConnected = connectedServices.includes(platform);
  
  const handleLogin = () => {
    login(platform);
  };
  
  return (
    <button
      onClick={handleLogin}
      disabled={isConnected}
      className={`w-full flex items-center justify-center py-3 px-4 rounded-md 
                 ${isConnected 
                   ? 'bg-gray-100 text-gray-500 cursor-not-allowed' 
                   : `${config.color} text-white ${config.hoverColor} transition-colors`}`}
    >
      <config.icon className="w-5 h-5 mr-2" />
      {isConnected 
        ? `Connected to ${config.name}` 
        : `Connect ${config.name}`}
    </button>
  );
};

export default LoginButton;