import React, { createContext, useContext, useState, useCallback } from 'react';
import { api } from '../services/api';

interface MessageCounts {
  teams: number;
  zoom: number;
  google: number;
}

interface MessageContextType {
  messages: MessageCounts;
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  refreshMessages: () => Promise<void>;
}

const MessageContext = createContext<MessageContextType | undefined>(undefined);

export const useMessage = () => {
  const context = useContext(MessageContext);
  if (!context) {
    throw new Error('useMessage must be used within a MessageProvider');
  }
  return context;
};

export const MessageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<MessageCounts>({
    teams: 0,
    zoom: 0,
    google: 0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  
  const refreshMessages = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // In a real app, this would be an actual API call
      // api.get('/messages/unread')
      
      // Simulate API response with random data
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockData = {
        teams: Math.floor(Math.random() * 15),
        zoom: Math.floor(Math.random() * 10),
        google: Math.floor(Math.random() * 20)
      };
      
      setMessages(mockData);
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Error refreshing messages:', err);
      setError('Failed to fetch message counts. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);
  
  return (
    <MessageContext.Provider value={{
      messages,
      loading,
      error,
      lastUpdated,
      refreshMessages
    }}>
      {children}
    </MessageContext.Provider>
  );
};