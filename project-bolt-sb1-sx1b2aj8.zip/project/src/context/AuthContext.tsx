import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';

type Platform = 'teams' | 'zoom' | 'google';

interface User {
  id: string;
  name: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (platform: Platform) => void;
  logout: () => void;
  connectedServices: Platform[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [connectedServices, setConnectedServices] = useState<Platform[]>([]);
  
  // Check if user is authenticated on initial load
  useEffect(() => {
    const checkAuth = async () => {
      try {
        setLoading(true);
        
        // In a real app, we would make an API call to verify the token
        const token = localStorage.getItem('auth_token');
        
        if (token) {
          // Simulate API call to get user and connected services
          // In a real app, this would be an actual API call
          setUser({
            id: '1',
            name: 'John Doe',
            email: 'john.doe@example.com'
          });
          setConnectedServices(['teams', 'zoom', 'google']);
        }
      } catch (error) {
        console.error('Authentication error:', error);
        localStorage.removeItem('auth_token');
        setUser(null);
        setConnectedServices([]);
      } finally {
        setLoading(false);
      }
    };
    
    checkAuth();
  }, []);
  
  const login = useCallback((platform: Platform) => {
    // In a real app, this would redirect to the OAuth endpoint
    const authEndpoints = {
      teams: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
      zoom: 'https://zoom.us/oauth/authorize',
      google: 'https://accounts.google.com/o/oauth2/v2/auth'
    };
    
    // Generate a random state for CSRF protection
    const state = Math.random().toString(36).substring(2);
    localStorage.setItem('oauth_state', state);
    
    // Simulate OAuth redirect
    console.log(`Redirecting to ${authEndpoints[platform]} for ${platform} login...`);
    
    // Mock implementation - in a real app we would redirect to the actual OAuth endpoint
    setTimeout(() => {
      setUser({
        id: '1',
        name: 'John Doe',
        email: 'john.doe@example.com'
      });
      
      if (!connectedServices.includes(platform)) {
        setConnectedServices([...connectedServices, platform]);
      }
      
      localStorage.setItem('auth_token', 'mock_token');
    }, 1000);
  }, [connectedServices]);
  
  const logout = useCallback(() => {
    // Clear auth token and reset state
    localStorage.removeItem('auth_token');
    setUser(null);
    setConnectedServices([]);
  }, []);
  
  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      loading,
      login,
      logout,
      connectedServices
    }}>
      {children}
    </AuthContext.Provider>
  );
};