import axios from 'axios';

// Create axios instance with base URL
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001/api',
});

// Add request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Service for Teams API
export const teamsService = {
  getUnreadCount: () => api.get('/teams/unread'),
  authorize: (code: string, state: string) => api.post('/teams/authorize', { code, state }),
};

// Service for Zoom API
export const zoomService = {
  getUnreadCount: () => api.get('/zoom/unread'),
  authorize: (code: string, state: string) => api.post('/zoom/authorize', { code, state }),
};

// Service for Google API
export const googleService = {
  getUnreadCount: () => api.get('/google/unread'),
  authorize: (code: string, state: string) => api.post('/google/authorize', { code, state }),
};