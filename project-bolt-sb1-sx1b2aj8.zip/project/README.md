# Message Notification Hub

A unified dashboard to monitor unread messages from Microsoft Teams, Zoom, and Google Meet in real time.

## Features

- **Real-Time Dashboard**: View unread message counts from multiple messaging platforms in one place
- **OAuth 2.0 Authentication**: Secure access to your messaging accounts
- **Auto-Refresh**: Data automatically updates every 60 seconds
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Getting Started

### Prerequisites

- Node.js 18 or higher
- npm or yarn

### Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/message-notification-hub.git
cd message-notification-hub
```

2. Install dependencies:
```
npm install
```

3. Copy the example environment file:
```
cp .env.example .env
```

4. Update the `.env` file with your API credentials (see [API Credentials Setup](#api-credentials-setup) below)

### Running the Application

Start the development server:
```
npm run dev
```

This will start both the frontend and backend servers:
- Frontend: http://localhost:5173
- Backend: http://localhost:3001

## API Credentials Setup

### Microsoft Teams (Microsoft Graph API)

1. Go to the [Azure Portal](https://portal.azure.com)
2. Navigate to Azure Active Directory > App registrations
3. Create a new registration
4. Set the redirect URI to `http://localhost:3000/auth/teams/callback`
5. Request the following permissions:
   - User.Read
   - Mail.Read
6. Copy the Client ID and Client Secret to your .env file

### Zoom

1. Go to the [Zoom App Marketplace](https://marketplace.zoom.us/)
2. Click "Develop" > "Build App"
3. Create an OAuth app
4. Set the redirect URL to `http://localhost:3000/auth/zoom/callback`
5. Add the following scopes:
   - chat_message:read
   - user:read
6. Copy the Client ID and Client Secret to your .env file

### Google Meet/Gmail

1. Go to the [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Navigate to APIs & Services > Credentials
4. Create an OAuth 2.0 Client ID
5. Add `http://localhost:3000/auth/google/callback` as an authorized redirect URI
6. Enable the Gmail API
7. Copy the Client ID and Client Secret to your .env file

## Project Structure

```
message-notification-hub/
├── public/              # Static assets
├── server/              # Backend Node.js server
│   ├── middleware/      # Express middleware
│   ├── routes/          # API routes
│   └── index.js         # Server entry point
├── src/                 # Frontend React application
│   ├── components/      # Reusable UI components
│   ├── context/         # React context providers
│   ├── pages/           # Page components
│   ├── services/        # API service functions
│   ├── App.tsx          # Main React component
│   └── main.tsx         # Entry point
├── .env.example         # Example environment variables
└── README.md            # Project documentation
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.